JEIEvents.hideItems(event => {
    event.hide("metamorphosis:artha_crystal_block")
    event.hide("metamorphosis:dharma_crystal_block")
    event.hide("metamorphosis:kama_crystal_block")
    event.hide("metamorphosis:moksha_crystal_block")

    event.hide("metamorphosis_computers:floppy_disk")
    event.hide("metamorphosis_computers:pocket_computer")
    event.hide("metamorphosis_computers:cable")
    event.hide("metamorphosis_computers:communication")
    event.hide("metamorphosis_computers:item_assimilation")
    event.hide("metamorphosis_computers:encryption_protocol")
    event.hide("metamorphosis_computers:upgrade")
    event.hide("metamorphosis_computers:computer")

    event.hide("metamorphosis_teleports:otherworldly_shifter")
    event.hide("metamorphosis_teleports:otherworldly_chrysalis")
})

JEIEvents.removeRecipes(event => {
    event.remove("minecraft:crafting", "metamorphosis_computers:computer_from_great_crystals")
    event.remove("create:mechanical_crafting", "metamorphosis_computers:computer_from_great_crystals")
    event.remove("create:automatic_shaped", "metamorphosis_computers:computer_from_great_crystals")
    event.remove("twilightforest:uncrafting", "metamorphosis_computers:computer_from_great_crystals")
})